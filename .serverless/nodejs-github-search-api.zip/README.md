
## Installation

1.  Install Dependencies

    * [Node.js (version 6.x is recommended)](https://nodejs.org/en/)

3.  Go to the project's root directory **cd /my/path/to/directory**
4.  Run **npm install**
5.  Start using it! **npm start**


Creates an event (be sure you are sending the headers via your library).

**Headers**

Content-Type : application/json




